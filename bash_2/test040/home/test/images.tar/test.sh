#!/bin/bash
#
# Test driver
#
. pre_test.sh
bash ./bash.sh
. post_test.sh
